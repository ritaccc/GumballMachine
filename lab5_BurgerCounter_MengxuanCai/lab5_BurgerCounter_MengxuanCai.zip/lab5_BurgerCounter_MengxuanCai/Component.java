 /** 
 * @MengxuanCai
 * @11/08/2016
 */
public interface Component {

     void printDescription() ;
     void addChild(Component c);
     void removeChild(Component c);
     Component getChild(int i);
}
 
