
/**
 * Write a description of interface BurgerComponent here.
 * 
 * @MengxuanCai
 * @11/18/2016
 */
public interface Burger
{

    public double getCost();
}
