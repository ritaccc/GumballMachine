 
/**
 * @MengxuanCai
 * @11/08/2016
 */
public class Client {
   
    public static void runTest()
    {
        Component theOrder = BuildOrder.getOrder();
        theOrder.printDescription();

    }
}
 
